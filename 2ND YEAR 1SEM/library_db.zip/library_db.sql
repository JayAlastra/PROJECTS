
-- Database: library_db

CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

-- Table: books
CREATE TABLE books (
    book_no VARCHAR(10) PRIMARY KEY,
    title VARCHAR(255),
    author VARCHAR(100),
    genre VARCHAR(50),
    subject VARCHAR(50),
    grade VARCHAR(10),
    total_quantity INT(11),
    available_quantity INT(11),
    is_archived TINYINT(1) DEFAULT 0
);

-- Table: borrowers
CREATE TABLE borrowers (
    id_number VARCHAR(20) PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50)
);

-- Table: users
CREATE TABLE users (
    user_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password_hash VARCHAR(255),
    role VARCHAR(20)
);

-- Table: borrow_records
CREATE TABLE borrow_records (
    record_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    borrower_id VARCHAR(20),
    book_no VARCHAR(10),
    date_borrowed DATE,
    due_date DATE,
    date_returned DATE,
    penalty DECIMAL(5,2) DEFAULT 0.00,
    FOREIGN KEY (borrower_id) REFERENCES borrowers(id_number) ON DELETE CASCADE,
    FOREIGN KEY (book_no) REFERENCES books(book_no) ON DELETE CASCADE
);

-- Sample Data
INSERT INTO books (book_no, title, author, genre, subject, grade, total_quantity, available_quantity, is_archived) VALUES
('B001', 'Introduction to Java', 'James Gosling', 'Programming', 'Computer Science', 'Grade 10', 5, 3, 0),
('B002', 'Modern Mathematics', 'Isaac Newton', 'Mathematics', 'Algebra', 'Grade 9', 4, 4, 0),
('B003', 'World History', 'Howard Zinn', 'History', 'Social Studies', 'Grade 8', 6, 0, 1);

INSERT INTO borrowers (id_number, first_name, last_name) VALUES
('2025-001', 'Maria', 'Reyes'),
('2025-002', 'John', 'Santos');

INSERT INTO users (username, password_hash, role) VALUES
('admin', 'admin123', 'Administrator'),
('staff1', 'staff123', 'Staff');

INSERT INTO borrow_records (borrower_id, book_no, date_borrowed, due_date, date_returned, penalty) VALUES
('2025-001', 'B001', '2025-10-01', '2025-10-10', '2025-10-09', 0.00),
('2025-002', 'B003', '2025-09-25', '2025-10-02', '2025-10-10', 15.00);
